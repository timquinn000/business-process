DECLARE @START_TIME AS datetime2;
DECLARE @END_TIME AS datetime2;
SELECT @START_TIME = '2019-01-02';
SELECT @END_TIME = '2019-01-03';
--##SELECT @START_TIME = '{starttime}';  -- The characters --## are replaced in the R script that calls this file
--##SELECT @END_TIME = '{endtime}';

--ToDo - Performance might be better if we pivot the CTEs to get the final result?
--     - We override completion time of direction so that it is always at least 1 millisecond after initiation
--     - (is this right?)

with entries as (
select
  e.[Entry ID] 
  ,'Lodgement' as 'Activity'
  ,e.[Original lodgement datetime] as 'start'
  ,NULL as 'complete' --DATEADD(SECOND, 1, convert(datetime2, [Original lodgement datetime])) as 'complete'
  ,e.[Entry SK]
  ,e.[Discharge port code] as 'discharge_port'
from
  [T2_BIOSECURITY].[AIMS].[Entry] e
where 
  e.[Document type ID] in ('FID', 'SCL')
  and e.[Original lodgement datetime]>=@START_TIME 
  and e.[Original lodgement datetime]<=@END_TIME
)

, int_proc AS (
  SELECT * FROM (
    VALUES
      ('XX:01', 'Placed back under BSC'),
      ('XX:02 Placed back under BSC', 'Placed back under BSC'),
      ('A0:01', 'Payment problem'),
      ('A0:02', 'Payment problem'),
      ('A0:03', 'Payment problem'),
      ('A0:04', 'Payment problem'),
      ('A0:06', 'Payment problem'),
      ('D0:17', 'Payment problem'),
      ('A0:24', 'Amended'),
      ('A0:30', 'Amended'),
      ('A0:44', 'Amended'),
      ('AP:01', 'Amended'),
      ('FP:30', 'Amended'),
      ('H0:14', 'Amended'),
      ('H0:15', 'Amended'),
      ('M3:03', 'Amended'),
      ('QP:10', 'Amended'),
      ('QP:13', 'Amended'),
      ('QP:14', 'Amended'),
      ('QS:QP', 'Amended')
  ) AS X ([Direction ID], [Intervention process])
)

, dirs as (
SELECT [Entry direction SK]
      ,e.[Entry ID]
      ,rd.[Direction category]
      ,rd.[Direction]
      ,case 
         when int_proc.[Intervention process] is not null then int_proc.[Intervention process]
         when rd.[Final direction] =1 then 'Final dir'
         else rd.Intervention
       end as 'Activity'
      -- this ensures initiation follows lodgement for sorting correctly
      ,DATEADD(SECOND, 1, convert(datetime2, [Initiating datetime])) as 'Initiating datetime'
      ,case when rd.Intervention in ('Admin', 'Documentation') 
         then NULL --DATEADD(SECOND, 2, convert(datetime2, [Latest completion datetime])) 
         else case when [Latest completion datetime] <= [Initiating datetime]
               then DATEADD(SECOND, 2, convert(datetime2, [Latest completion datetime]))
               else [Latest completion datetime]
             end 
       end as 'Latest completion datetime'
      ,e.discharge_port
FROM [T2_BIOSECURITY].[AIMS].[Direction] d
  inner join entries e on e.[Entry SK] = d.[Entry SK]
  inner join [T2_BIOSECURITY].[AIMS].RefDirection rd on rd.[Direction ID]=d.[Direction ID]
  left join int_proc on int_proc.[Direction ID] = rd.[Direction ID]
where 1=1
  and rd.[Direction category] <> 'Documentation - Self-assessed'
)

, alldata as (

select 
  e.[Entry ID] 
  ,e.Activity as 'Activity'
  ,e.[start] as 'Start datetime'
  ,e.complete as 'Complete datetime'
  ,'Lodgement' as 'Direction category'
  ,'Lodgement' as 'Direction'
  ,0 as 'Entry direction SK'
  --,e.discharge_port as 'Discharge port'
from 
  entries e

-- The following greatly increases the query time and doesn't return
-- much for the periods I have tested. It works off a T1_AIMS view and
-- so might be sped up by querying the primary tables if it is deemed useful
--
--union all
--select 
--  PrimaryKeyList as 'Entry ID'
--  ,'Re-lodged' as 'Activity'
--  ,[AuditDateTime] as 'start_datetime'
--  ,DATEADD(SECOND, 1, [AuditDateTime]) as 'complete_datetime'
--  ,'Re-lodged' as 'Direction category'
--  ,'Re-lodged' as 'Direction'
--  ,0 as 'Entry direction SK'
--from [T1_AIMS].[dbo].[vwAudit] a
--  inner join entries e on e.[Entry ID] = a.PrimaryKeyList
--where 1=1
--    and [TableChanged]='aiEntry'
--    and [AuditDateTime] > '2020-03-28'
--    and [AuditDateTime] < '2020-03-29'
--    and ColumnChanged = 'EntryVersion'

union all

select 
  [Entry ID]
  ,Activity
  ,[Initiating datetime]
  ,d.[Latest completion datetime]
  ,d.[Direction category] 
  ,d.Direction
  ,d.[Entry direction SK]
  --,d.discharge_port
from dirs d
where 1=1
  and Activity not in ('Admin')
) 

--, unpivoted as (
--SELECT 
--  Activity, 
--  entry, 
--  status, 
--  event_time,
--  Activity_instance,
--  discharge_port
--FROM   
--   (SELECT Activity, entry, start, complete, discharge_port,
--     ROW_NUMBER() OVER(ORDER BY start ASC) as 'Activity_instance'  
--   FROM alldata) p  
--UNPIVOT  
--   (event_time FOR [status] IN   
--      (start, complete)  
--) AS unpvt
--)

select 
  a.[Entry ID]
  ,a.Activity
  ,a.[Start datetime]
  ,a.[Complete datetime]
  ,a.[Direction category]
  ,a.[Direction]
  ,a.[Entry direction SK]
  --,[Discharge port]
  ,ROW_NUMBER() OVER(ORDER BY [Start datetime] ASC) as 'Activity instance'
from alldata a
where 1=1
-- and Activity<>'Lodgement'
order by 
  [Entry ID], 
  [Start datetime]


--union all

--select 
--  [Entry ID] as 'entry'
--  ,[Direction category]
--  ,'complete' as 'status'
--  ,[Latest completion datetime]
--  ,Activity_instance + (select top 1 maxrow from max_row) +  1e6
--from dirs
--) 

--select * 
--from final_data 
--where event_time is not null
--and [entry] in ('AEKNNYC3F', 'AEKNPFM6X')
----and Activity_instance in (1010354,1010355)
--order by [entry], event_time, Activity_instance, status desc
