
REFRESH <- FALSE
IMS_SQL <- 'IMS_events.sql'
DATA_FILE <- 'IMS_bpm.RData'
starttime <- '2021-01-02'
endtime <- '2021-01-03'

if (!REFRESH) load(DATA_FILE)

if (!exists('events')) {events <- get.events(starttime, endtime, filename=IMS_SQL)}

events %<>% 
  filter(activity!='Finalised in AIMS') %>% 
  mutate(activity_instance=1:nrow(.))

event_log <- events %>% 
  as.events() %>% 
  as.ims.log() %>% 
  filter(status!='scheduled') %>% 
  throughput_time(level = "case", append = TRUE) %>% 
  processing_time('case', append=TRUE)

case.count <- events$entry_id %>% 
  unique() %>% 
  length()

event.counts <- events %>% 
  group_by(activity) %>% 
  summarise(Event.count = length(activity),
            Cases.count = length(unique(entry_id))) 




