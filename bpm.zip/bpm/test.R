
# Define a function
library_loc <- function(x, repos='file:///R:/cran.r-project.org') {
  if(!require(x)){ install.packages(x, repos=repos ,lib=.libPaths()) }
  library(x)
}

#Load some libs
library_loc('scales')
library_loc('ggplot2')
