DECLARE @START_TIME AS datetime2;
DECLARE @END_TIME AS datetime2;
SELECT @START_TIME = '2019-01-02';
SELECT @END_TIME = '2019-01-06';
--##SELECT @START_TIME = '{starttime}';  -- The characters --## are replaced in the R script that calls this file
--##SELECT @END_TIME = '{endtime}';

--ToDo - Performance might be better if we pivot the CTEs to get the final result?
--     - We override completion time of direction so that it is always at least 1 millisecond after initiation
--     - (is this right?)

with entries as (
select
  e.[Entry ID] 
  ,'Lodgement' as 'activity'
  ,e.[Original lodgement datetime] as 'start'
  ,e.[Finalisation date] as 'complete'
  ,e.[Entry SK]
  ,e.[Discharge port code] as 'discharge_port'
from
  [T2_BIOSECURITY].[AIMS].[Entry] e
where 
  e.[Document type ID] in ('FID', 'SCL')
  and e.[Original lodgement datetime]>=@START_TIME 
  and e.[Original lodgement datetime]<=@END_TIME
)

, dirs as (
SELECT [Entry direction SK]
      ,e.[Entry ID]
      ,rd.[Direction category]
      -- this ensures initiation follows lodgement
      ,DATEADD(MILLISECOND, 1, convert(datetime2, [Initiating datetime])) as 'Initiating datetime'
      --,datediff(s, [Initiating datetime], [Latest completion datetime]) as 'difftime'
      ,case when [Latest completion datetime] <= [Initiating datetime]
         then DATEADD(MILLISECOND, 2, convert(datetime2, [Latest completion datetime]))
         else [Latest completion datetime]
       end as 'Latest completion datetime'
      ,e.discharge_port
FROM [T2_BIOSECURITY].[AIMS].[Direction] d
  inner join entries e on e.[Entry SK] = d.[Entry SK]
  inner join [T2_BIOSECURITY].[AIMS].RefDirection rd on rd.[Direction ID]=d.[Direction ID]
where 1=1
  and rd.[Direction category] <> 'Documentation - Self-assessed'
  --and [Initiating datetime]<e.start
)

, alldata as (

select 
  e.[Entry ID] as 'entry'
  ,e.activity
  ,e.[start] 
  ,e.complete 
  ,e.discharge_port
from 
  entries e

union all

select 
  [Entry ID]
  ,[Direction category]
  ,[Initiating datetime]
  ,d.[Latest completion datetime]
  ,d.discharge_port
from dirs d
) 



, unpivoted as (
SELECT 
  activity, 
  entry, 
  status, 
  event_time,
  activity_instance,
  discharge_port
FROM   
   (SELECT activity, entry, start, complete, discharge_port,
     ROW_NUMBER() OVER(ORDER BY start ASC) as 'activity_instance'  
   FROM alldata) p  
UNPIVOT  
   (event_time FOR [status] IN   
      (start, complete)  
) AS unpvt
)
select entry, activity, status, event_time, activity_instance, discharge_port 
from unpivoted
where 1=1
-- and activity<>'Lodgement'
order by entry, event_time


--union all

--select 
--  [Entry ID] as 'entry'
--  ,[Direction category]
--  ,'complete' as 'status'
--  ,[Latest completion datetime]
--  ,activity_instance + (select top 1 maxrow from max_row) +  1e6
--from dirs
--) 

--select * 
--from final_data 
--where event_time is not null
--and [entry] in ('AEKNNYC3F', 'AEKNPFM6X')
----and activity_instance in (1010354,1010355)
--order by [entry], event_time, activity_instance, status desc
