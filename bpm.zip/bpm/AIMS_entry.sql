
SELECT 
  e.*
  ,dis.[Standardised port name] as [Discharge port]
  ,dp.[Standardised port name] as [Destination port]
  ,rs.*
FROM[T2_BIOSECURITY].[T3_IMPORTS].[Entry] e 
  inner join [T2_BIOSECURITY].[Ref].[Port] dis on dis.[Port code]=e.[Discharge port code]
  inner join [T2_BIOSECURITY].[Ref].[Port] dp on dp.[Port code]=e.[Destination port code]
  left join [T3_IMPORTS].[RefSummary] rs on rs.[Summary SK] = e.[Summary SK]
  left join [T3_IMPORTS].[RefAssuranceSummary] ras on ras.[Assurance summary SK] = e.[Assurance summary SK]
where 
  e.[Entry ID] in ('{entries}')
  