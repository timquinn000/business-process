
library(RODBC)
library(tidyverse)
library(processanimateR)
library(bupaR)
library(htmlwidgets)
library(glue)
library(DiagrammeR)
library(magrittr)

# Suppress summarise info
options(dplyr.summarise.inform = FALSE)
STD_SQL_FILE <- 'IMS_event_log.sql'
IMS_LEVELS <- c("Lodgement","Profile match","Assessment",
                "Documents received","Movement withheld", 
                "Inspection","Upgraded","Finalised", "Released to AA")

toproper <- function(x) paste0(toupper(substr(x, 1, 1)), tolower(substring(x, 2))) %>% 
  str_replace('_id$', '_ID') %>% 
  str_replace('_sk$', '_SK') %>% 
  str_replace_all('\\.|_', ' ') 

tor <- function(x) gsub(' ', '_', x) %>% tolower()

#Can't change dir with saveWidget???
save.widget <- function(x, dir, filename=paste0(deparse(substitute(x)), '.html')){
  plotsfile <- file.path(dir, filename)
  saveWidget(x, filename)
  if (file.exists(plotsfile)) file.remove(plotsfile)
  file.copy(filename, plotsfile)
  invisible(file.remove(filename))
}

get.events <- function(starttime='2021-01-02', endtime=starttime, filename=STD_SQL_FILE){
  
  db_handle <- odbcDriverConnect("driver={SQL Server};
                                   server=ACT001VBSRPTP01;
                                   database=T2_BIOSECURITY;
                                   trusted_connection=true",
                                 believeNRows=FALSE, rows_at_time = 1)
  
  sql <- readChar(filename, file.info(filename)$size) %>% 
    gsub('--##', '', .)
  
  
  events <- RODBC::sqlQuery(db_handle, str_glue(sql)) %>%
    tibble() %>% 
    rename_with(tor)
  
  odbcClose(db_handle)
  events
  
}

get.entries <- function(entries, filename){
  
  db_handle <- odbcDriverConnect("driver={SQL Server};
                                   server=ACT001VBSRPTP01;
                                   database=T2_BIOSECURITY;
                                   trusted_connection=true",
                                 believeNRows=FALSE, rows_at_time = 1)
  
  sql <- readChar(filename, file.info(filename)$size) %>% 
    gsub('--##', '', .)
  
  
  events <- RODBC::sqlQuery(db_handle, str_glue(sql)) %>%
    tibble()
  odbcClose(db_handle)
  events %>% 
    rename_with(tor)
  
}

as.events <- function(query_result){

  query_result %>%
    rename_with(tor) %>% 
    mutate(start_datetime=as.POSIXct(start_datetime),
           complete_datetime=as.POSIXct(complete_datetime)) %>% 
    rename_with(tor) %>%
    arrange(entry_id, start_datetime) %>%
    pivot_longer(
      cols = c(start_datetime, complete_datetime),
      names_to = "status",
      values_to = "event_datetime",
    ) %>% 
    filter(!is.na(event_datetime)) %>% 
    mutate(status=gsub('_datetime', '', status))
}

as.ims.log <- function(ims.events) {
  ims.events %>% 
    eventlog(
      case_id = "entry_id",
      activity_id = "activity",
      activity_instance_id = "activity_instance",
      lifecycle_id = "status",
      timestamp = "event_datetime",
      resource_id = "destination_port"
    ) %>% 
    mutate(activity = factor(activity, levels = IMS_LEVELS))
}


short.trace <- function(x) {
  sht.trc <- function(z) {
    stringr::str_split(z, pattern = ',') %>%
      unlist() %>% 
      substr(1, 1) %>% 
      paste(collapse=',')
  }
  sapply(x, sht.trc)
}

# Take an entry log and return a datamodel with entities: case, trace, case_trace 
# (an association table)
pbi.datamodel <- function(x){
  
  case_col <- attr(x, 'case_id')
  #res_col <- attr(x, 'resource_id')
  
  cases <- tibble(case = unique(x[[case_col]])) 
  names(cases) <- case_col
  
  traces <- x %>% 
    trace_length(level = 'trace') %>% 
    arrange(desc(absolute)) %>% 
    rename(trace_length=absolute) %>% 
    mutate(trace_id = short.trace(trace)) %>% 
    select(trace_id, trace_length, relative_to_median, trace)
  
  throughput <- x %>% 
    group_by(!! sym(case_col)) %>% 
    summarise(throughput_time = min(throughput_time_case))
  
  tl <- x %>% 
    trace_length(level = "case") %>% 
    rename(trace_length=absolute)
    
  case_trace <- x %>% 
    trace_coverage(level = "case") %>% 
    select(!! sym(case_col), 
           trace) %>% 
    left_join(traces %>% select(trace, trace_id), by='trace') %>% 
    select(-trace) 
  
  cases %<>% 
    left_join(throughput, by=case_col) %>% 
    left_join(tl, by=case_col) 
    
  traces %<>% select(-trace)
  
  return(list(
    cases = cases,
    case_trace = case_trace,
    traces = traces,
    event_log = x
  ))
  
}
                         
layout_lr <- data.frame(
  act=c('ARTIFICIAL_START', 'Lodgement', 'Profile match', 'Assessment', 'Documents received', 'Inspection', 'ARTIFICIAL_END'),
  x=c(0, 1.2, 2.5, 4, 5.5, 5.5, 7),
  y=c(2, 2, 2,   2, 3,   1, 2)
)

layout_tb <- data.frame(
  act=c('ARTIFICIAL_START', 'Lodgement', 'Profile match', 'Assessment', 'Documents received', 'Inspection', 'ARTIFICIAL_END'),
  x=c(2, 2, 2, 2, 3, 1, 2),
  y=c(7, 6, 5, 4, 3, 3, 2)
)











# event_log %>% process_map(layout=layout_pm(layout_ims)) ->x
# 
# event_log %>% process_map(render=F) -> x

