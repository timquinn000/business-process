--IMS events
DECLARE @START_TIME AS datetime2;
DECLARE @END_TIME AS datetime2;
SELECT @START_TIME = '2021-01-02';
SELECT @END_TIME = '2021-01-03';
--##SELECT @START_TIME = '{starttime}';  -- The characters --## are replaced in the R script that calls this file
--##SELECT @END_TIME = '{endtime}';

with [entries] as (
SELECT 
   e.[Entry SK]
  ,e.[Entry ID]
  ,p.[Standardised port name] as 'Destination port'
FROM 
  [T2_BIOSECURITY].[IMS].[Entry] e
  inner join [T2_BIOSECURITY].[Ref].Port p on p.[Port code] = e.[Destination port code]
WHERE
  e.[Estimated arrival date] >= @START_TIME 
  and e.[Estimated arrival date] < @END_TIME
)

, [dirs] AS (
  SELECT * FROM (
    VALUES
      ('Final directive - finalised and released', 'Finalised', 0),
      ('Final directive - duplicate entry', 'Finalised', 0),
      ('Goods verification required - AA', 'Inspection', 1),
      ('Goods inspect required', 'Inspection', 1),
      ('Final directive - Admin duplicated entry', 'Finalised', 0),
      ('Formal entry required', 'Upgraded', 0),
      ('Movement withheld - secure goods pending advice', 'Movement withheld', 0),
      ('Movement withheld - Pending information', 'Movement withheld', 0),
      ('Documentation - Present all documentation', 'Present documents', 1),
      ('Inspection required (department)', 'Inspection', 1),
      ('Inspection - Air Freight Inspection', 'Inspection', 1),
      ('Subject to AA - released', 'Released to AA', 0)
  ) AS X ([Direction], [Activity], [Ignore])
)

, finaldir as (
select
  [Direction ID]
from 
  [T2_BIOSECURITY].[AIMS].[RefDirection]
where 
  [Final direction]=1
)

, finalisations as (
select 
  es.[Entry ID] 
  ,'Finalised' as 'activity'
  ,d.[Initiating datetime] as 'start_datetime'
  ,d.[Latest completion datetime] as 'complete_datetime'
  ,es.[Destination port]
from 
  [T2_BIOSECURITY].[AIMS].[Direction] d
  inner join  finaldir fd on fd.[Direction ID] = d.[Direction ID]
  inner join [T2_BIOSECURITY].[AIMS].[Entry] e on e.[Entry SK] = d.[Entry SK]
  inner join entries es on es.[Entry SK] = e.[Entry SK] 
where 
  [Direction status]='Completed'
--group by
--  es.[Entry ID]
--  ,es.[Destination port]
)

, profile_events as (
SELECT 
  s.[Entry ID] 
  ,min(p.[Match datetime]) as 'start_datetime'
  ,max(p.[Match datetime]) as 'complete_datetime'
  ,s.[Destination port]
FROM 
  [T2_BIOSECURITY].[IMS].[ProfileMatch] p
  inner join entries s on s.[Entry SK]=p.[Entry SK]
group by
  s.[Entry ID]
  ,s.[Destination port]
)

, alldata as (
select 
   f.[Entry ID]
  ,f.activity
  ,f.start_datetime
  ,f.complete_datetime
  ,f.[Destination port]
from 
  finalisations f

UNION ALL

select
  e.[Entry ID]
  ,d.Activity
  ,o.[Creation datetime]
  ,dateadd(second, 1, o.[Creation datetime])
  ,e.[Destination port]
from 
  [T2_BIOSECURITY].[IMS].[Outcome] o
    inner join entries e on e.[Entry SK] = o.[Entry SK]
    inner join dirs d on d.Direction = o.Direction
where
  d.Ignore = 0

UNION ALL

-- ToDo: I assume [Original lodgement datetime]<>[Creation datetime] when an entry is 
-- amended and therefore re-lodged. Perhaps we need to interrogate the audit logs
-- to get correct timestamps for lodgement?
SELECT 
   s.[Entry ID] as 'entry'
  ,'Lodgement' as 'activity'
  ,e.[Original lodgement datetime] as 'start_datetime'
  ,e.[Creation datetime] as 'complete_datetime'
  ,s.[Destination port]
FROM 
  [T2_BIOSECURITY].[IMS].[Entry] e
  inner join entries s on s.[Entry SK]=e.[Entry SK]

UNION ALL

SELECT 
  e.[Entry ID]
  ,'Documents received' 
  ,e.[Documents received datetime]
  ,e.[Documents received datetime]
  ,s.[Destination port]
FROM 
  [T2_BIOSECURITY].[IMS].[Entry] e
  inner join entries s on s.[Entry SK]=e.[Entry SK]
WHERE
  [Documents received datetime] IS NOT NULL

UNION ALL

SELECT 
  p.[Entry ID]
  ,'Profile match' 
  ,p.start_datetime
  ,p.complete_datetime
  ,p.[Destination port]
FROM 
  profile_events p

UNION ALL

SELECT 
  s.[Entry ID]
  ,h.[Task category]
  ,h.[Creation datetime]
  ,h.[Finalisation datetime]
  ,s.[Destination port]
FROM 
  [T2_BIOSECURITY].[IMS].[Task] h
  inner join entries s on s.[Entry SK]=h.[Entry SK]
WHERE 
  (Completed=1 or [Assignment datetime] is not null)
)


select 
  a.[Entry ID]
  ,a.activity
  ,a.start_datetime
  ,a.complete_datetime
  ,a.[Destination port]
from alldata a
order by 
   a.[Entry ID]
  ,a.start_datetime