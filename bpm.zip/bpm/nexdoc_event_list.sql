
with initial as (
select  
  r.REX_NUMBER
  ,'ORDER' as 'activity'
  ,DATEADD(SECOND, -1, convert(datetime2, [RCH_CHANGE_TS]))  as 'start_datetime'
  ,h.[AUDIT_CHANNEL]
  ,h.[AUDIT_EVENT]
  ,h.[VERSION]
  ,'complete' as 'lifecycle_id'
  ,ROW_NUMBER() OVER(ORDER BY [RCH_CHANGE_TS] ASC) as 'Activity instance'
from [T1_NEXDOC].[DA_ECM].[ECM_REX_CHANGE_HISTORY] h
  inner join [T1_NEXDOC].[DA_ECM].[ECM_REX] r on r.REX_ID = h.RCH_REX_ID
where [RCH_ATR_NAME] = 'status' and [RCH_OLD_VALUE] = '"ORDER"'
)

, nxt as (
select  
  r.REX_NUMBER
  ,replace([RCH_NEW_VALUE], '"', '') as 'activity'
  ,[RCH_CHANGE_TS]
  ,h.[AUDIT_CHANNEL]
  ,h.[AUDIT_EVENT]
  ,h.[VERSION]
  ,'complete' as 'lifecycle_id'
  ,ROW_NUMBER() OVER(ORDER BY [RCH_CHANGE_TS] ASC) + (
    select count(*) from [T1_NEXDOC].[DA_ECM].[ECM_REX_CHANGE_HISTORY] x
    where x.[RCH_ATR_NAME] = 'status' and x.[RCH_OLD_VALUE] = '"ORDER"')  as 'Activity instance'
from [T1_NEXDOC].[DA_ECM].[ECM_REX_CHANGE_HISTORY] h
 inner join [T1_NEXDOC].[DA_ECM].[ECM_REX] r on r.REX_ID = h.RCH_REX_ID
where [RCH_ATR_NAME] = 'status'
)

select * from initial
union all
select * from nxt