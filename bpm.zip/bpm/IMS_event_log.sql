DECLARE @START_TIME AS datetime2;
DECLARE @END_TIME AS datetime2;
SELECT @START_TIME = '2021-01-02';
SELECT @END_TIME = '2021-01-02';
--##SELECT @START_TIME = '{starttime}';  -- The characters --## are replaced in the R script that calls this file
--##SELECT @END_TIME = '{endtime}';

with [entries] as (
SELECT 
   e.[Entry SK]
  ,e.[Entry ID]
  ,e.[Destination port code]
FROM 
  [T2_BIOSECURITY].[IMS].[Entry] e
WHERE
  e.[Estimated arrival date] >= @START_TIME 
  and e.[Estimated arrival date] <= @END_TIME
)

, finaldir as (
select
  [Direction ID]
from 
  [T2_BIOSECURITY].[AIMS].[RefDirection]
where 
  [Final direction]=1
)

, finalisations as (
select 
  es.[Entry ID] as 'entry'
  ,'Finalised in AIMS' as 'activity'
  ,'complete' as 'status'
  ,MAX([Latest completion datetime]) as 'event_time'
from 
  [T2_BIOSECURITY].[AIMS].[Direction] d
  inner join  finaldir fd on fd.[Direction ID] = d.[Direction ID]
  inner join [T2_BIOSECURITY].[AIMS].[Entry] e on e.[Entry SK] = d.[Entry SK]
  inner join entries es on es.[Entry SK] = e.[Entry SK] 
where 
  [Direction status]='Completed'
group by
  es.[Entry ID]
)

, profile_events as (
SELECT 
  s.[Entry ID] as 'entry'
  ,MAX([Match datetime]) as 'event_time'
FROM 
  [T2_BIOSECURITY].[IMS].[ProfileMatch] h
  inner join entries s on s.[Entry SK]=h.[Entry SK]
group by
  s.[Entry ID]
)

, [events] as (

select 
  *
  ,ROW_NUMBER() OVER(PARTITION BY [entry] ORDER BY event_time ASC) as 'instance'
from 
  finalisations

UNION ALL

SELECT 
   s.[Entry ID] as 'entry'
  ,'Lodgement' as 'activity'
  ,'complete' as 'status'
  ,e.[Original lodgement datetime] as 'event_time'
  ,ROW_NUMBER() OVER(ORDER BY e.[Original lodgement datetime] ASC) as 'instance'
FROM 
  [T2_BIOSECURITY].[IMS].[Entry] e
  inner join entries s on s.[Entry SK]=e.[Entry SK]

UNION ALL

SELECT 
   e.[Entry ID] as 'entry'
  ,'Assessment' as 'activity'
  ,'scheduled' as 'status'
  ,e.[Assessment due datetime] as 'event_time'
  ,1 as 'instance'
FROM 
  [T2_BIOSECURITY].[IMS].[Entry] e
  inner join entries s on s.[Entry SK]=e.[Entry SK]

UNION ALL

SELECT 
  s.[Entry ID] as 'entry'
  ,'Documents received' 
  ,'complete' as 'status'
  ,[Documents received datetime]
  ,ROW_NUMBER() OVER(ORDER BY [Documents received datetime] ASC) as 'instance'
FROM 
  [T2_BIOSECURITY].[IMS].[Entry] e
  inner join entries s on s.[Entry SK]=e.[Entry SK]
WHERE
  [Documents received datetime] IS NOT NULL

UNION ALL

SELECT 
  p.[entry]
  ,'Profile match' 
  ,'complete'
  ,p.event_time
  ,ROW_NUMBER() OVER(ORDER BY p.event_time ASC) as 'instance'
FROM 
  profile_events p

UNION ALL

SELECT 
  s.[Entry ID]
  ,[Task category]
  ,'start'
  ,[Creation datetime]
  ,ROW_NUMBER() OVER(PARTITION BY s.[Entry ID] ORDER BY [Creation datetime] ASC) as 'activity_instance'
FROM 
  [T2_BIOSECURITY].[IMS].[Task] h
  inner join entries s on s.[Entry SK]=h.[Entry SK]
WHERE 
  (Completed=1 or [Assignment datetime] is not null)

UNION ALL

SELECT 
  s.[Entry ID]
  ,[Task category]
  ,'complete'
  ,[Finalisation datetime]
  ,ROW_NUMBER() OVER(PARTITION BY s.[Entry ID] ORDER BY [Creation datetime] ASC) as 'activity_instance'
FROM 
  [T2_BIOSECURITY].[IMS].[Task] h
  inner join entries s on s.[Entry SK]=h.[Entry SK]
WHERE 
  (Completed=1 or [Assignment datetime] is not null)
) 

select 
   [entry]
  ,[entries].[Destination port code] as 'dest_port'
  ,[activity]
  ,[status]
  ,[event_time]
  ,[instance]
  ,DENSE_RANK() OVER(ORDER BY [entry], [activity], [instance])  as 'activity_instance'
from 
  [events]
  inner join [entries] on [entries].[Entry ID] = [events].[entry]
--where [entry] in ('AEJXNTGGJ', 'AEJWK4MMX')
where
  [event_time] is not null

order by 
   [entry]
  --,[activity]
  ,[event_time]
