

declare @START_TIME datetime2 = '2019-01-01';
declare @END_TIME datetime2 = '2019-12-31';
declare @MAX_CASES int = 100;

--##SELECT @START_TIME = '{starttime}';  -- The parameters values and the characters "--##" are replaced in the R script that calls this file
--##SELECT @END_TIME = '{endtime}';
--##SELECT @MAX_CASES = '{maxcases}';

--ToDo - Performance might be better if we pivot the CTEs to get the final result?
--     - We override completion time of direction so that it is always at least 1 millisecond after initiation
--     - (is this right?)

-- Create a temp table rather than CTE to avoid calling this more than once
drop table if exists #temp_aims_entry_ids;
set nocount on;
create table #temp_aims_entry_ids ([Entry SK] int);
insert into #temp_aims_entry_ids
select top (@MAX_CASES) [Entry SK] 
    from [T2_BIOSECURITY].[T3_IMPORTS].[Entry] e
    where
    --e.[Entry ID] = 'AC9HGP4WH'
    e.[Document type ID] in ('FID', 'SCL')
    and e.[Original lodgement date]>=@START_TIME 
    and e.[Original lodgement date]<=@END_TIME
    order by newid();
set nocount off;

with entries as (
select
  'Lodgement' as 'Activity'
  ,cast(e.[Original lodgement date] as datetime) + cast(e.[Original lodgement time] as datetime) as 'start'
  ,NULL as 'complete' --DATEADD(SECOND, 1, convert(datetime2, [Original lodgement datetime])) as 'complete'
  ,e.*
FROM [T2_BIOSECURITY].[T3_IMPORTS].[Entry] e
  inner join #temp_aims_entry_ids i on i.[Entry SK]=e.[Entry SK]
)

, special AS (
  SELECT * FROM (
    VALUES
      ('XX:01', 'Back under BSC'),
      ('XX:02 Placed back under BSC', 'Back under BSC'),
      ('A0:01', 'Settlement problem'),
      ('A0:02', 'Settlement problem'),
      ('A0:03', 'Settlement problem'),
      ('A0:04', 'Settlement problem'),
      ('A0:06', 'Settlement problem'),
      ('D0:17', 'Settlement problem'),
      ('A0:24', 'Amended'),
      ('A0:30', 'Amended'),
      ('A0:44', 'Amended'),
      ('AP:01', 'Amended'),
      ('FP:30', 'Amended'),
      ('H0:14', 'Amended'),
      ('H0:15', 'Amended'),
      ('M3:03', 'Amended'),
      ('QP:10', 'Amended'),
      ('QP:13', 'Amended'),
      ('QP:14', 'Amended'),
      ('QS:QP', 'Amended'),
      ('A0:35', 'Permit conds'),
      ('A0:46', 'Permit conds'),
      ('D0:01', 'Permit conds'),
      ('G0:18', 'Permit conds'),
      ('O0:06', 'Permit conds'),
      ('R0:23', 'Permit conds')  -- NOTE; This is a final dir but the goods remain in BSC
  ) AS X ([Direction ID], [Intervention process])
)

, dirs as (
SELECT [Entry direction SK]
      ,e.[Entry ID]
      ,rd.[Direction category]
      ,rd.[Direction]
      ,rl.[Location state]
      ,case 
         when s.[Intervention process] is not null then s.[Intervention process]
         when rd.[Final direction] = 1 then 'Final dir'
         else rd.Intervention
       end as 'Activity'
      -- this ensures initiation follows lodgement for sorting correctly
      ,DATEADD(SECOND, 1, convert(datetime2, [Initiating datetime])) as 'Initiating datetime'
      ,case when rd.Intervention in ('Admin', 'Documentation') 
         then NULL --DATEADD(SECOND, 2, convert(datetime2, [Latest completion datetime])) 
         else case when [Latest completion datetime] <= [Initiating datetime]
               then DATEADD(SECOND, 2, convert(datetime2, [Latest completion datetime]))
               else [Latest completion datetime]
             end 
       end as 'Latest completion datetime'
      ,e.[Discharge port code]
FROM entries e
  inner join [T2_BIOSECURITY].[AIMS].[Direction] d on e.[Entry SK] = d.[Entry SK]
  inner join [T2_BIOSECURITY].[AIMS].RefDirection rd on rd.[Direction ID]=d.[Direction ID]
  left join special s on s.[Direction ID] = rd.[Direction ID]
  left join [T2_BIOSECURITY].[AIMS].[RefLocation] rl on rl.[Location ID]=d.[Location ID]
where 1=1
  and rd.[Direction category] <> 'Documentation - Self-assessed'
)

--select [Entry ID]  from entries

, alldata as (

select 
  e.[Entry ID] 
  ,e.Activity as 'Activity'
  ,e.[start] as 'Start datetime'
  ,e.complete as 'Complete datetime'
  ,'Lodgement' as 'Direction category'
  ,'Lodgement' as 'Direction'
  ,0 as 'Entry direction SK'
  ,'ACT' as 'Location state'
from 
  entries e

union all

select 
  [Entry ID]
  ,Activity
  ,[Initiating datetime]
  ,d.[Latest completion datetime]
  ,d.[Direction category] 
  ,d.Direction
  ,d.[Entry direction SK]
  ,d.[Location state]
from dirs d
where 1=1
  and Activity not in ('Admin')
) 

--select distinct [Entry ID]  from alldata


select 
  a.[Entry ID]
  ,case a.Activity
     when 'Export' then 'Export_destroy'
     when 'Destroy' then 'Export_destroy'
     else a.Activity
   end as 'Activity'
  ,a.[Start datetime]
  ,a.[Complete datetime]
  ,a.[Direction category]
  ,a.[Direction]
  ,a.[Entry direction SK]
  ,a.[Location state]
  ,ROW_NUMBER() OVER(ORDER BY [Start datetime] ASC) as 'Activity instance'
from alldata a
where 1=1
-- and Activity<>'Lodgement'
order by 
  [Entry ID], 
  [Start datetime]

